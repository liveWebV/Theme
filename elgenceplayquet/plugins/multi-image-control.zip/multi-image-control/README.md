# Multi Image Control (work in progress)

*A Theme customizer control allowing selection and sorting of multiple images.*

Currently under refactoring to make it compatible with WordPress latest versions.

## Installing
* download and place in WordPress plugin folder
* activate the plugin
* use it